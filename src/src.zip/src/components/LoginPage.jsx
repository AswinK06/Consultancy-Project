import React from 'react';
import styles from '../styles/LoginPage.module.css';
import { Input } from './Input';

export function LoginPage() {
  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className={styles.loginContainer}>
      <img
        loading="lazy"
        src="https://cdn.builder.io/api/v1/image/assets/cefa1649806149578fe3d15c65143941/fc0ff708db7fbf8d927196a712d7f731cdc8f75dd0e0ce4108ef26b596f9f67e?apiKey=cefa1649806149578fe3d15c65143941&"
        className={styles.logo}
        alt="Temple logo"
      />
      <div className={styles.welcomeText}>
        Welcome to Arulmigu Sri Ramaperumal Kovil
      </div>
      <div className={styles.formWrapper}>
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/cefa1649806149578fe3d15c65143941/09eb033318bfa3b13ea028586747b6112a15d5ab9cd13df1cc1ccc38667acb69?apiKey=cefa1649806149578fe3d15c65143941&"
          className={styles.backgroundImage}
          alt=""
        />
        <form className={styles.formContainer} onSubmit={handleSubmit}>
          <Input
            label="Mobile Number"
            type="tel"
            placeholder="Enter your mobile number"
            id="mobileNumber"
          />
          <Input
            label="password"
            type="password"
            placeholder="Enter your password"
            id="password"
          />
          <button type="submit" className={styles.loginButton}>
            login
          </button>
        </form>
      </div>
    </div>
  );
}