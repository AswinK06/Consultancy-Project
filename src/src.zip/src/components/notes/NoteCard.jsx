import React from 'react';
import styles from './Notes.module.css';

export const NoteCard = ({ title, content, date, imageSrc }) => {
  const imageUrl = imageSrc ? `http://localhost:8080${imageSrc}` : null;

  // Debugging: Check if imageUrl is correct
  console.log('Image URL:', imageUrl);

  return (
    <article className={styles.noteCard}>
      <div className={styles.noteCardContainer}>
        {imageUrl && (
          <img
            loading="lazy"
            src={imageUrl}
            alt={`Note illustration for ${title}`}
            className={styles.noteImage}
          />
        )}
        <h3 className={styles.noteTitle}>{title}</h3>
        <div className={styles.noteContent}>
          {content}
        </div>
      </div>
      <time className={styles.noteDate}>{date}</time>
    </article>
  );
};
