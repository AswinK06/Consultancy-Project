import React from 'react';
import styles from './Notes.module.css';

export const PoojaCard = ({ title, content, date, imageSrc }) => {
  const imageUrl = imageSrc ? `http://localhost:8080${imageSrc}` : null;

  // Debugging: Check if imageUrl is correct
  console.log('Image URL:', imageUrl);

  return (
    <article className={styles.poojaCard}>
      <div className={styles.poojaCardContainer}>
        {imageUrl && (
          <img
            loading="lazy"
            src={imageUrl}
            alt={`Pooja illustration for ${title}`}
            className={styles.poojaImage}
          />
        )}
        <h3 className={styles.poojaTitle}>{title}</h3>
        <div className={styles.poojaContent}>
          {content}
        </div>
      </div>
      {date && <time className={styles.poojaDate}>{date}</time>}
    </article>
  );
};
